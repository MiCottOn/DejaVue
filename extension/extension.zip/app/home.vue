<template>
  <div id="homeContainer">
    <h1>{{title}}</h1>
  </div>
  
</template>

<script>
 
export default {
  name: 'home',
  data() {
    return {
      title: 'Component Hierarchy'
    }
  }
}
</script>

